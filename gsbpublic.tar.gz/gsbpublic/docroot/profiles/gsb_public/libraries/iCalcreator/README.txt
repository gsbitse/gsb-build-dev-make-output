iCalcreator
is a PHP class managing iCal (rfc2445/rfc5445) formatted files for non-calendar
systems like CMS, project management systems and other applications able to
process calendar information like agendas, tasks, reports, totos, journaling
data and for communication with calendar systems and applications.
