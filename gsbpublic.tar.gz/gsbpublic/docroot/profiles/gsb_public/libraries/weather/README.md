weather
=======

Weather widget
