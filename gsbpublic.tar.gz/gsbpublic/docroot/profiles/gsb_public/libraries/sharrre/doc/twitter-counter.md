# Twitter Counter

Since Nov. 2015, Twitter disabled the share counts from its API, thus we can no longer get or display them.

If you want to get the display count anyway,
you can create an account for free (as of Feb. 2016) on https://opensharecount.com/.

The Twitter platform shipped with Sharrre is already configured to use this API.